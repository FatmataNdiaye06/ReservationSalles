<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détail salle - DalalSpace</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>

<body>

<div class="page">

    <header class="navbar">

        <a href="../index.html" class="logo">
            <span class="logo-icon">D</span>
            <span>Dalal<span>Space</span></span>
        </a>

        <nav class="nav-links">
            <a href="../index.html">Accueil</a>
            <a href="index.html" class="active">Salles</a>
            <a href="../reservation/index.html">Réservations</a>
            <a href="../reservation/form.html" class="nav-button">
                + Nouvelle réservation
            </a>
        </nav>

    </header>


    <main class="main-content">

        <div class="breadcrumb">
            <a href="index.html">Salles</a>
            <span>›</span>
            <span>Amphithéâtre A</span>
        </div>


        <section class="detail-card">

            <div class="detail-header">

                <div>
                    <span class="page-label">DÉTAIL DE LA SALLE</span>

                    <h1>Amphithéâtre A</h1>

                    <p>Bâtiment A · Salle #001</p>
                </div>

                <span class="badge success large">
                    Active
                </span>

            </div>


            <div class="detail-grid">

                <div class="detail-item">
                    <span>Capacité</span>
                    <strong>250 places</strong>
                </div>

                <div class="detail-item">
                    <span>Type</span>
                    <strong>Amphithéâtre</strong>
                </div>

                <div class="detail-item">
                    <span>Bâtiment</span>
                    <strong>Bâtiment A</strong>
                </div>

                <div class="detail-item">
                    <span>Créée le</span>
                    <strong>01/09/2026</strong>
                </div>

            </div>


            <div class="detail-actions">

                <a href="index.html" class="secondary-button">
                    ← Retour
                </a>

                <a href="form.html" class="secondary-button">
                    Modifier
                </a>

                <button class="danger-button">
                    Désactiver
                </button>

            </div>

        </section>


        <section class="table-card">

            <div class="table-top">
                <div>
                    <h2>Réservations de la salle</h2>
                    <span>Réservations à venir</span>
                </div>
            </div>


            <div class="table-wrapper">

                <table>

                    <thead>
                        <tr>
                            <th>Responsable</th>
                            <th>Motif</th>
                            <th>Date</th>
                            <th>Horaire</th>
                            <th>Statut</th>
                        </tr>
                    </thead>

                    <tbody>

                        <tr>
                            <td><strong>Fatou Diop</strong></td>
                            <td>Soutenance de projet</td>
                            <td>11/09/2026</td>
                            <td>14:00 - 16:00</td>
                            <td>
                                <span class="badge success">
                                    Confirmée
                                </span>
                            </td>
                        </tr>

                    </tbody>

                </table>

            </div>

        </section>

    </main>


    <footer class="footer">
        <p>© 2026 <strong>DalalSpace</strong> — Gestion des salles</p>
    </footer>

</div>

</body>
</html>
